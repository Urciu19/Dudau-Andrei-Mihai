const luni = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

const btnDetalii = document.getElementById("btnDetalii");
const containerDetalii = document.getElementById("detalii");
const spanData = document.getElementById("dataProdus");


containerDetalii.classList.add("ascuns");

const dataAzi = new Date();
const zi = dataAzi.getDate();
const lunaText = luni[dataAzi.getMonth()];
const an = dataAzi.getFullYear();

spanData.textContent = `${zi} ${lunaText} ${an}`;

btnDetalii.addEventListener("click", function() {
    
    containerDetalii.classList.toggle("ascuns");

    if (!containerDetalii.classList.contains("ascuns")) {
        btnDetalii.textContent = "Ascunde detalii";
    } else {
        btnDetalii.textContent = "Afiseaza detalii";
    }
});