const luni = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

const btnAdauga = document.getElementById("btnAdauga");
const inputActivitate = document.getElementById("inputActivitate");
const listaActivitati = document.getElementById("listaActivitati");

btnAdauga.addEventListener("click", function() {
    const textActivitate = inputActivitate.value;

    if (textActivitate !== "") {
        const elementNou = document.createElement("li");

        const dataCurenta = new Date();
        const ziua = dataCurenta.getDate();
        const luna = luni[dataCurenta.getMonth()];
        const an = dataCurenta.getFullYear();

        elementNou.textContent = `${textActivitate} - adaugata la: ${ziua} ${luna} ${an}`;

        listaActivitati.appendChild(elementNou);

        inputActivitate.value = "";
    } else {
        alert("Te rog introdu o activitate!");
    }
});